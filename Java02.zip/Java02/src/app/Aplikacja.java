/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;
import utils.Matematyka;
import java.util.Random;
import java.util.Arrays;
import static utils.Tablice.Suma;
import static utils.Tablice.Sortuj;
import static utils.Tablice.Maksimum;


/**
 *
 * @author BartD
 */
public class Aplikacja {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Matematyka m = new Matematyka();
        System.out.println("Metoda pierwsza silnia: ");
        int i =0;
        while (i<=10)
        {
        System.out.println(i + " " + m.silnia1(i++));
        }
        
        Matematyka m1 = new Matematyka();
        
        System.out.println("Metoda druga silnia2: ");
        int j;
        for (j=0; j<=10; j++)
        {
        System.out.println(j + " " + m1.silnia2(j));
        }
      
        
        System.out.println("wygenerowana tablica: ");
        int [] tablica = new int [10];
        
        for(int k =0; k<tablica.length; k++)
        {
   
            Random rand = new Random();
            int  n = rand.nextInt(50) + 1;
            tablica[k] = n;
            System.out.println(k+1 + " wyraz tablicy to: " +tablica[k]);
        
        }
        System.out.println("dlugość tablicy to; " + tablica.length);
            
      Suma(tablica);    
        System.out.println("suma tab; " + Suma(tablica));
        
      Maksimum(tablica);    
      System.out.println("Max tab: " + Maksimum(tablica));
        
       Sortuj(tablica); 
       System.out.println("sortowana tab: " + Arrays.toString(Sortuj(tablica)));
    }
    
}