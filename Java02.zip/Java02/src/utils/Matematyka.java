/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;


/**
 *
 * @author BartD
 */
public class Matematyka {
    
    /**
     *
     * @param l
     * @return
     * @throws ArithmeticException
     */
    public static long silnia1 (int l) throws java.lang.ArithmeticException
    {
        long silnia =1;
        if(l<0)
        {
            throw new java.lang.ArithmeticException("liczba ujemna");
        }else
        for (int i=1; i<=l; i++)
        {
            silnia = silnia * i;
        }
        return silnia;
    }
    
    public static long silnia2 (int licz) throws java.lang.ArithmeticException
    {
        if (licz<0)
        {
            throw new java.lang.ArithmeticException("liczba ujemna");
        } else 
        if (licz==0)
        {
            return 1;
        }   
        else {
            
            return licz * silnia2(licz-1);
        }
            
            
    }
    
    
}
