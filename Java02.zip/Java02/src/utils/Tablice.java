/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;
import java.util.Arrays;

/**
 *
 * @author BartD
 */
public class Tablice {
    
    public static int Maksimum(int tab[])
    {
    Arrays.sort(tab);
       
       int [] tabb = new int [10];
       
       for(int a=0; a<tab.length; a++)
       {
           tabb[a]=tab[a];
       }
                   
    return tabb[tabb.length-1];
    }

    /**
     *
     * @param tab
     * @return
     */
    public static int Suma(int tab[])
    {
        int suma = 0;
         for(int y=0; y<tab.length; y++)
         {
          suma = suma + tab[y];
         }
         return suma;
    }
    /**
     *
     * @param tab
     * @return 
     */
    public static int [] Sortuj(int [] tab)
            
    {   
       Arrays.sort(tab);
       
       int [] tabb = new int [10];
       
       for(int a=0; a<tab.length; a++)
       {
           tabb[a]=tab[a];
       }
       
       return tabb;
    }   
    
    
}
