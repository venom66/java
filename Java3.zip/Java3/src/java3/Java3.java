/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java3;
import test.Samochod;
import test.Samolot;

/**
 *
 * @author BartD
 */
public class Java3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
        Samochod s1 = new Samochod(5,"bmw",5);
            
        int p = s1.getPredkosc();
        
        Samolot sam = new Samolot();
        
    }
    
}
