/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java3;
import test.Pojazd;
import test.Samochod;
import test.Samolot;
import test.Tuningowalny;

/**
 *
 * @author BartD
 */
public class Java3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
        Pojazd s1 = new Samochod(5,"bmw",5);
            
        int p = s1.getPredkosc();
        
        Samolot sam = new Samolot();
        
        Tuningowalny a = new Samochod();
        
        int b = ((Samochod)a).getPredkosc();
        
        System.out.println("predkosc przed tuningiem: " + b);
        
        int d = ((Samochod)a).zwiekszPredkosc(55); 
        
        System.out.println("predkosc samochodu po tuningu:" + d);
        
        
        
        
    }
    
}
