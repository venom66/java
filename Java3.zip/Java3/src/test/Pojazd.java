/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author BartD
 */
public abstract class Pojazd {
    
    protected int predkosc = 100;
    protected String model = "AIR";
    
    public Pojazd()
    {}
    
    public Pojazd (int predkosc, String model)
    {
        this.predkosc=predkosc;
        this.model = model;
    }
    

    /**
     * @return the predkosc
     */
    public int getPredkosc() {
        return predkosc;
    }

    /**
     * @param predkosc the predkosc to set
     */
    public void setPredkosc(int predkosc) {
        this.predkosc = predkosc;
    }

    /**
     * @return the model
     */
    public String getModel() {
        return model;
    }

    /**
     * @param model the model to set
     */
    public void setModel(String model) {
        this.model = model;
    }
    
    public void showPojazd(int predkosc, String model)
    { 
        this.predkosc = predkosc;
        this.model = model;
        System.out.println("model:" + getModel()); 
        System.out.println("predkosc:" + getPredkosc());
        
    }
    
       public void showPojazd()
    { 
        System.out.println("model: " + getModel());
        System.out.println("predkosc:" + getPredkosc());
        
    }
       /*
    @Override
    public int zwiekszPredkosc(int predkosc) {
        return
        predkosc+= getPredkosc();
    }
    */
}
