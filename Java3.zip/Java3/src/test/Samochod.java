/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author BartD
 */
public class Samochod extends Pojazd implements Tuningowalny {
    
    protected int liczbaDrzwi;

    /**
     * @return the liczbaDrzwi
     */
    public int getLiczbaDrzwi() {
        return liczbaDrzwi;
    }

    /**
     * @param liczbaDrzwi the liczbaDrzwi to set
     */
    public void setLiczbaDrzwi(int liczbaDrzwi) {
        this.liczbaDrzwi = liczbaDrzwi;
    }
    
    public Samochod (int predkosc, String model, int liczbaDrzwi)
    {
        this.liczbaDrzwi = liczbaDrzwi;
        this.predkosc = predkosc;
        this.model = model;
        
    }
    
        public Samochod (int predkosc, String model)
    {
        this.predkosc = predkosc;
        this.model = model;
        
    }
    
    
    
    public Samochod()
            {}
    
    public void Samochod (int predkosc, String model)
    {

        this.predkosc = predkosc;
        this.model = model;
        System.out.println("predkosc: " + predkosc);
        System.out.println("model: " + model);
        
    }

    /**
     *
     * @param predkosc
     * @return
     */
    @Override
    public int zwiekszPredkosc(int predkosc) {
        return
        predkosc+= getPredkosc();
    }
 
}
