/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;
import test.Pojazd;


/**
 *
 * @author BartD
 */
public class Samolot extends Pojazd {
    
    protected int liczbaMiejsc;

    /**
     * @return the liczbaMiejsc
     */
    public int getLiczbaMiejsc() {
        return liczbaMiejsc;
    }

    /**
     * @param liczbaMiejsc the liczbaMiejsc to set
     */
    public void setLiczbaMiejsc(int liczbaMiejsc) {
        this.liczbaMiejsc = liczbaMiejsc;
    }
    
    public Samolot()
    {}
    
    public Samolot(int liczbaMiejsc, int predkosc, String model)
    {
        this.liczbaMiejsc = liczbaMiejsc;
        this.predkosc = predkosc;
        this.model = model;
        
    }
    
    public void showSamolot(int liczbaMiejsc, int predkosc, String model)
    {
        this.liczbaMiejsc = liczbaMiejsc;
        this.predkosc = predkosc;
        this.model = model;
        System.out.println("liczba miejsc: " + liczbaMiejsc);
        System.out.println("predkosc: " + getPredkosc());
        System.out.println("model: " + getModel());
    }
    
    public Samolot (int predkosc, String model)
    {
        this.predkosc = predkosc;
        this.model = model;
        
    }
   
    
    
}
