/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;


/**
 *
 * @author BartD
 */
public class test {
    
    public static void main(String[] args) {
        // TODO code application logic here
       
      Pojazd [] pojazdy = new Pojazd[4];
      
      pojazdy[0] = new Samochod(100, "bmw");
      pojazdy[1] = new Samochod(100, "audi");
      pojazdy[2] = new Samolot(300, "Concord");
      pojazdy[3] = new Samolot(350, "Superjet");
        
      for(int i=0; i<4; i++)
      {
          System.out.println("-------------------------------------petla for: ");
          System.out.println(i+1 + " pojazd to: ");
            pojazdy[i].showPojazd();
      }
      System.out.println("--------------------------------------petla foearch:");
    
      int i =0;
      for(Pojazd x: pojazdy)  
      {     
            System.out.println(i+1 + " pojazd " + " to:");
            pojazdy[i].showPojazd();
            i++;
            
      }
      
        System.out.println("--------------------------zwiekszanie predkosci:  ");
        System.out.println("predkosc poczatkowa pojazdu: " + pojazdy[0].getPredkosc());
        int y = pojazdy[0].zwiekszPredkosc(10);
        System.out.print("predkosc zwiekszona: ");
        System.out.print(y);
    
        
    }
    
}
